
var http = require('http');


// 发送请求
http.request({
  host:   '127.0.0.1',
  port:   8080,
  path:   '/json',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  }
},function (res) {
  
  var data = '';
  res.on('data', function (chunk) {
    data += chunk;
  });
  res.on('end', function () {
    // 解析服务器返回的数据
    var json = JSON.parse(data);
    console.log('服务器返回信息：' + json.msg);
  });
  
// 将数据转换为JSON字符串被发送
}).end(JSON.stringify({name: '张三', age: 23}));
