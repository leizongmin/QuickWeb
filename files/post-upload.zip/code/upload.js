/**
 * 用于测试的页面
 */
 
exports.path = '/upload';

exports.post = function (req, res) {
  // 监听post complete事件
  req.on('post complete', function () {
    if (!req.file || !req.file.stream) {
      console.log('没有上传文件！');
      res.sendJSON({error: '没有上传文件！'});
    }
    else {
      console.log('上传文件已保存到：' + req.file.stream.path);
      res.send({success: '上传文件已保存到：' + req.file.stream.path});
    }
  });
  
  // 监听post error事件
  req.on('post error', function (err) {
    console.error('解析POST数据时出错：' + err.stack);
    res.sendError(500, err);
  });
}

