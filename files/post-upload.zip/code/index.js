/**
 * 用于测试的页面
 */
 

exports.post = function (req, res) {
  // 监听post complete事件
  req.on('post complete', function () {
    // POST参数
    console.log('姓名：' + req.post.name);
    console.log('年龄：' + req.post.age);
    // 上传文件
    if (req.file) {
      console.log('头像文件：' + req.file.face.path);
      // 输出该头像
      res.sendFile(req.file.face.path);
    }
    else {
      res.send('没有上传头像！');
    }
  });
  
  // 监听post error事件
  req.on('post error', function (err) {
    console.error('解析POST数据时出错：' + err.stack);
    res.sendError(500, err);
  });
}

